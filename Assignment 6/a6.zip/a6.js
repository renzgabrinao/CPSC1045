"use strict";

let ctx;
let colors = ['red','green','blue','purple','yellow','orange','pink'];

let peopleArray=[];

function setup() {
	ctx=document.getElementById("myCanvas").getContext("2d");
	
}


//Draws a person at position (x,y) which is bottom center
//color is a string setting the color
//if child is true, then a child is drawn (half sized person)
//An adult is 50 pixels tall, a child is 25
//An adult is 40 pixels wide, a child is 20
function drawPerson(x,y,color,child) {
	let height = 50;
	let halfWidth = 20;
	if (child) {
		height *= .5;
		halfWidth *= .5;
	}
	ctx.save();
	ctx.translate(x,y);
	ctx.strokeStyle=color;
	ctx.beginPath();
	ctx.lineTo(-halfWidth*.75,0);
	ctx.lineTo(0, -height/3);
	ctx.lineTo(halfWidth*.75,0);
	ctx.lineTo(0, -height/3);
	ctx.lineTo(0, -2*height/3);
	ctx.lineTo(0, -7*height/12);	
	ctx.lineTo(halfWidth,-2*height/3);
	ctx.lineTo(0, -7*height/12);	
	ctx.lineTo(-halfWidth,-2*height/3);		
	ctx.stroke();
	ctx.beginPath();
	ctx.arc(0,-5*height/6,height/6,0,2*Math.PI);
	ctx.stroke();
	
	ctx.restore();
}

